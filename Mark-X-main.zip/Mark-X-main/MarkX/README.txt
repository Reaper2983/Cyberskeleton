# 🤖 Jarvis Mark X — Local AI Desktop Assistant

Jarvis Mark X is a **local, modular AI desktop assistant** inspired by Jarvis and built from scratch using **Python**.

It allows you to control your computer with voice commands and an intent → action system.

## 🚀 Features
- Open applications
- Send messages (WhatsApp)
- Web search 
- Weather reports
- Temporary & long-term memory
- Chatting with good memory


## 🎥 Tutorial
This project is part of a **video tutorial series**.  
Please watch the tutorial to understand the architecture and how to safely extend the system.
video: https://youtu.be/ZD6kf9w9Sy0?si=DvySsKIeL4RuAjVt

## 🔐 Security Notice
- Runs **100% locally**
- No remote access by default
- Jarvis only executes what **YOU code**

⚠️ Do NOT paste unknown code or give full system control to untrusted scripts.

---

## ⚠️ Usage Warning
- **No commercial use**
- Do NOT sell, market, or monetize
- Do NOT present this project as your own on social media

You may use and modify it for **personal and educational purposes**.

---

## 📲 Follow & Contact
Instagram: https://www.instagram.com/fatihmakes/  
TikTok: https://www.tiktok.com/@fatihmakes  

If you have issues or suggestions, feel free to reach out.

⭐ Like, follow, and subscribe for future Jarvis upgrades!
